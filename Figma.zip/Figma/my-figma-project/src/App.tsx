"use client";

import React, { useState } from "react";
import { ChatMessage } from "./components/ChatMessage";
import { PropertyCard } from "./components/PropertyCard";
import { PropertyDetailPage } from "./components/PropertyDetailPage";
import { Send, MessageCircle, X } from "lucide-react";
import { motion } from "framer-motion";
import clsx from "clsx";

// === Progress component from your file ===
import * as ProgressPrimitive from "@radix-ui/react-progress";

function cn(...classes: string[]) {
  return classes.filter(Boolean).join(" ");
}

function Progress({
  className,
  value,
  ...props
}: React.ComponentProps<typeof ProgressPrimitive.Root>) {
  return (
    <ProgressPrimitive.Root
      data-slot="progress"
      className={clsx( "bg-primary/20 relative h-2 w-full overflow-hidden rounded-full"
        , className
    )}
      {...props}
    >
      <ProgressPrimitive.Indicator
        data-slot="progress-indicator"
        className="bg-primary h-full w-full flex-1 transition-all"
        style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
      />
    </ProgressPrimitive.Root>
  );
}

// === Example App ===
export function App() {
  const [progress, setProgress] = useState(50);

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">My App</h1>

      {/* Example Progress bar */}
      <div>
        <p>Loading Progress: {progress}%</p>
        <Progress value={progress} className="w-full" />
        <button
          className="mt-2 px-4 py-2 bg-blue-600 text-white rounded"
          onClick={() => setProgress((prev) => Math.min(prev + 10, 100))}
        >
          Increase
        </button>
      </div>

      {/* Example ChatMessage usage */}
      <ChatMessage
        role="assistant"
        content="Here is a property for you!"
        properties={[
          {
            id: "1",
            url: "https://example.com",
            price: "$500,000",
            bed: "3",
            bath: "2",
            address: "123 Main St",
            city: "Austin",
            state: "TX",
            zip: "78701",
            mainImg: "https://via.placeholder.com/150",
          },
        ]}
        onPropertyClick={(property) => console.log("Clicked:", property)}
      />
    </div>
  );
}
